create table CDH(
  row_id varchar(100) not null,
  business_unit varchar(100) not null,
  customer_name varchar(100) not null,
  member_number varchar(30) not null,
  oracle_account_number int not null,
  eam_name varchar(100),
  eam_number int,
  efx_company_number int not null,
  efx_sales_rep varchar(100),
  last_update_date_time DATE,
  last_updated_by VARCHAR(100),
  low_family_number varchar(100),
  main_phone int,
  main_fax int,
  addr_line_1 varchar(100) not null,
  addr_line_2 varchar(100),
  city varchar(100) not null,
  country varchar(100) not null,
  state varchar(30) not null,
  province varchar(30) not null,
  zipcode varchar(30) not null,
  PRIMARY KEY (row_id)
  );
  
  
  create table CMS(
     row_id varchar(100) not null,
     account_status varchar(30),
	 high_family_name varchar(100),
	 high_family_number varchar(100),
     mdr_account boolean,
     sales_vertical int,
     PRIMARY KEY (row_id)	 
  );
  
  