package com.util;

public class ReimbBankInfo {

	private String reimburseBankName;
	private String advisingBankCode;
	private String availableWith;
	private String establishedBy;
	private String negotiation;
	private String chargesForAccount;
	private String periodOfPresentn;
	private String confirmRequired;
	private String checkboxValue;

	public String getReimburseBankName() {
		return reimburseBankName;
	}

	public void setReimburseBankName(String reimburseBankName) {
		this.reimburseBankName = reimburseBankName;
	}

	public String getAdvisingBankCode() {
		return advisingBankCode;
	}

	public void setAdvisingBankCode(String advisingBankCode) {
		this.advisingBankCode = advisingBankCode;
	}

	public String getAvailableWith() {
		return availableWith;
	}

	public void setAvailableWith(String availableWith) {
		this.availableWith = availableWith;
	}

	public String getEstablishedBy() {
		return establishedBy;
	}

	public void setEstablishedBy(String establishedBy) {
		this.establishedBy = establishedBy;
	}

	public String getNegotiation() {
		return negotiation;
	}

	public void setNegotiation(String negotiation) {
		this.negotiation = negotiation;
	}

	public String getChargesForAccount() {
		return chargesForAccount;
	}

	public void setChargesForAccount(String chargesForAccount) {
		this.chargesForAccount = chargesForAccount;
	}

	public String getPeriodOfPresentn() {
		return periodOfPresentn;
	}

	public void setPeriodOfPresentn(String periodOfPresentn) {
		this.periodOfPresentn = periodOfPresentn;
	}

	public String getConfirmRequired() {
		return confirmRequired;
	}

	public void setConfirmRequired(String confirmRequired) {
		this.confirmRequired = confirmRequired;
	}

	public String getCheckboxValue() {
		return checkboxValue;
	}

	public void setCheckboxValue(String checkboxValue) {
		this.checkboxValue = checkboxValue;
	}


	public String toString() {
		return "ReimbBankInfo [reimburseBankName=" + reimburseBankName + ", advisingBankCode=" + advisingBankCode
				+ ", availableWith=" + availableWith + ", establishedBy=" + establishedBy + ", negotiation="
				+ negotiation + ", chargesForAccount=" + chargesForAccount + ", periodOfPresentn=" + periodOfPresentn
				+ ", confirmRequired=" + confirmRequired + ", checkboxValue=" + checkboxValue + "]";
	}

}
