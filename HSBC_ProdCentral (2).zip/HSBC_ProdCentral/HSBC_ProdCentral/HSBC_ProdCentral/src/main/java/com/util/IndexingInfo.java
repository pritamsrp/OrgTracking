package com.util;

/**
 *  This is Indexing.
 * @author prasad.kale
 *
 */
public class IndexingInfo {

	private String customerName;
	private String customerACNumber;
	private String currency;
	private String transactionAmount;
	private String appReference;
	private String appReceivedDate;
	private String dcNumber;
	private String expiryDate;
	private String otherBankRef;
	private String createdUser;
	private String createdDate;
	private String workItemRef;
	private String country;

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerACNumber() {
		return customerACNumber;
	}

	public void setCustomerACNumber(String customerACNumber) {
		this.customerACNumber = customerACNumber;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(String transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public String getAppReference() {
		return appReference;
	}

	public void setAppReference(String appReference) {
		this.appReference = appReference;
	}

	public String getAppReceivedDate() {
		return appReceivedDate;
	}

	public void setAppReceivedDate(String appReceivedDate) {
		this.appReceivedDate = appReceivedDate;
	}

	public String getDcNumber() {
		return dcNumber;
	}

	public void setDcNumber(String dcNumber) {
		this.dcNumber = dcNumber;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getOtherBankRef() {
		return otherBankRef;
	}

	public void setOtherBankRef(String otherBankRef) {
		this.otherBankRef = otherBankRef;
	}

	public String getCreatedUser() {
		return createdUser;
	}

	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getWorkItemRef() {
		return workItemRef;
	}

	public void setWorkItemRef(String workItemRef) {
		this.workItemRef = workItemRef;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}
	public String toString() {
		return "IndexingInfo [customerName=" + customerName + ", customerACNumber=" + customerACNumber + ", currency="
				+ currency + ", transactionAmount=" + transactionAmount + ", appReference=" + appReference
				+ ", appReceivedDate=" + appReceivedDate + ", dcNumber=" + dcNumber + ", expiryDate=" + expiryDate
				+ ", otherBankRef=" + otherBankRef + ", createdUser=" + createdUser + ", createdDate=" + createdDate
				+ ", workItemRef=" + workItemRef + ", country=" + country + "]";
	}

}
