package com.util;

public class PanelInfo {

	private String action;
	private IndexingInfo indexingInfo;
	private CommonInfo commonInfo;
	private ReimbBankInfo reimbBankInfo;
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public IndexingInfo getIndexingInfo() {
		return indexingInfo;
	}
	public void setIndexingInfo(IndexingInfo indexingInfo) {
		this.indexingInfo = indexingInfo;
	}
	public CommonInfo getCommonInfo() {
		return commonInfo;
	}
	public void setCommonInfo(CommonInfo commonInfo) {
		this.commonInfo = commonInfo;
	}
	public ReimbBankInfo getReimbBankInfo() {
		return reimbBankInfo;
	}
	public void setReimbBankInfo(ReimbBankInfo reimbBankInfo) {
		this.reimbBankInfo = reimbBankInfo;
	}
	public String toString() {
		return "PanelInfo [action=" + action + ", indexingInfo=" + indexingInfo + ", commonInfo=" + commonInfo
				+ ", reimbBankInfo=" + reimbBankInfo + "]";
	}

}
