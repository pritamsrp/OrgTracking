package com.util;
/**
 * This Class is For Storing CommonInfo 
 * @author prasad.kale
 *
 */
public class CommonInfo {
	
	/**
	 *  Holds value of id.
	 */
	private int id;
	/**
	 *  Holds Value of createdUser.
	 */
	private String createdUser;
	/**
	 *  Holds Value of createdDate.
	 */
	private String createdDate;
	/**
	 *  Holds Value 
	 */
	/**
	 * 
	 */
	private String updatedUser;
	private String updatedDate;
	private String[] reference;
	private String channel;
	private String targetCompletion;
	private String custSegment;
	private String startingPageNo;
	private String supplimentary;
	private String channelInDateTime;
	private String branchCode;
	private String priority;
	private String lob;
	private String portfolioCode;
	private String processingSite;
	private String processType;
	private String email;
	/*public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCreatedUser() {
		return createdUser;
	}

	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedUser() {
		return updatedUser;
	}

	public void setUpdatedUser(String updatedUser) {
		this.updatedUser = updatedUser;
	}

	public String getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String[] getReference() {
		return reference;
	}

	public void setReference(String[] reference) {
		this.reference = reference;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getTargetCompletion() {
		return targetCompletion;
	}

	public void setTargetCompletion(String targetCompletion) {
		this.targetCompletion = targetCompletion;
	}

	public String getCustSegment() {
		return custSegment;
	}

	public void setCustSegment(String custSegment) {
		this.custSegment = custSegment;
	}

	public String getStartingPageNo() {
		return startingPageNo;
	}

	public void setStartingPageNo(String startingPageNo) {
		this.startingPageNo = startingPageNo;
	}

	public String getSupplimentary() {
		return supplimentary;
	}

	public void setSupplimentary(String supplimentary) {
		this.supplimentary = supplimentary;
	}

	public String getChannelInDateTime() {
		return channelInDateTime;
	}

	public void setChannelInDateTime(String channelInDateTime) {
		this.channelInDateTime = channelInDateTime;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getLob() {
		return lob;
	}

	public void setLob(String lob) {
		this.lob = lob;
	}

	public String getPortfolioCode() {
		return portfolioCode;
	}

	public void setPortfolioCode(String portfolioCode) {
		this.portfolioCode = portfolioCode;
	}

	public String getProcessingSite() {
		return processingSite;
	}

	public void setProcessingSite(String processingSite) {
		this.processingSite = processingSite;
	}

	public String getProcessType() {
		return processType;
	}

	public void setProcessType(String processType) {
		this.processType = processType;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}*/

	
	public String toString() {
		return "CommonInfo [id=" + id + ", createdUser=" + createdUser + ", createdDate=" + createdDate
				+ ", updatedUser=" + updatedUser + ", updatedDate=" + updatedDate + ", reference=" + reference
				+ ", channel=" + channel + ", targetCompletion=" + targetCompletion + ", custSegment=" + custSegment
				+ ", startingPageNo=" + startingPageNo + ", supplimentary=" + supplimentary + ", channelInDateTime="
				+ channelInDateTime + ", branchCode=" + branchCode + ", priority=" + priority + ", lob=" + lob
				+ ", portfolioCode=" + portfolioCode + ", processingSite=" + processingSite + ", processType="
				+ processType + ", email=" + email + "]";
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the createdUser
	 */
	public String getCreatedUser() {
		return createdUser;
	}

	/**
	 * @param createdUser
	 *            the createdUser to set
	 */
	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	/**
	 * @return the createdDate
	 */
	public String getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate
	 *            the createdDate to set
	 */
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the updatedUser
	 */
	public String getUpdatedUser() {
		return updatedUser;
	}

	/**
	 * @param updatedUser
	 *            the updatedUser to set
	 */
	public void setUpdatedUser(String updatedUser) {
		this.updatedUser = updatedUser;
	}

	/**
	 * @return the updatedDate
	 */
	public String getUpdatedDate() {
		return updatedDate;
	}

	/**
	 * @param updatedDate
	 *            the updatedDate to set
	 */
	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}

	/**
	 * @return the reference
	 */
	public String[] getReference() {
		return reference;
	}

	/**
	 * @param reference
	 *            the reference to set
	 */
	public void setReference(String[] reference) {
		this.reference = reference;
	}

	/**
	 * @return the channel
	 */
	public String getChannel() {
		return channel;
	}

	/**
	 * @param channel
	 *            the channel to set
	 */
	public void setChannel(String channel) {
		this.channel = channel;
	}

	/**
	 * @return the targetCompletion
	 */
	public String getTargetCompletion() {
		return targetCompletion;
	}

	/**
	 * @param targetCompletion
	 *            the targetCompletion to set
	 */
	public void setTargetCompletion(String targetCompletion) {
		this.targetCompletion = targetCompletion;
	}

	/**
	 * @return the custSegment
	 */
	public String getCustSegment() {
		return custSegment;
	}

	/**
	 * @param custSegment
	 *            the custSegment to set
	 */
	public void setCustSegment(String custSegment) {
		this.custSegment = custSegment;
	}

	/**
	 * @return the startingPageNo
	 */
	public String getStartingPageNo() {
		return startingPageNo;
	}

	/**
	 * @param startingPageNo
	 *            the startingPageNo to set
	 */
	public void setStartingPageNo(String startingPageNo) {
		this.startingPageNo = startingPageNo;
	}

	/**
	 * @return the supplimentary
	 */
	public String getSupplimentary() {
		return supplimentary;
	}

	/**
	 * @param supplimentary
	 *            the supplimentary to set
	 */
	public void setSupplimentary(String supplimentary) {
		this.supplimentary = supplimentary;
	}

	/**
	 * @return the channelInDateTime
	 */
	public String getChannelInDateTime() {
		return channelInDateTime;
	}

	/**
	 * @param channelInDateTime
	 *            the channelInDateTime to set
	 */
	public void setChannelInDateTime(String channelInDateTime) {
		this.channelInDateTime = channelInDateTime;
	}

	/**
	 * @return the branchCode
	 */
	public String getBranchCode() {
		return branchCode;
	}

	/**
	 * @param branchCode
	 *            the branchCode to set
	 */
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	/**
	 * @return the priority
	 */
	public String getPriority() {
		return priority;
	}

	/**
	 * @param priority
	 *            the priority to set
	 */
	public void setPriority(String priority) {
		this.priority = priority;
	}

	/**
	 * @return the lob
	 */
	public String getLob() {
		return lob;
	}

	/**
	 * @param lob
	 *            the lob to set
	 */
	public void setLob(String lob) {
		this.lob = lob;
	}

	/**
	 * @return the portfolioCode
	 */
	public String getPortfolioCode() {
		return portfolioCode;
	}

	/**
	 * @param portfolioCode
	 *            the portfolioCode to set
	 */
	public void setPortfolioCode(String portfolioCode) {
		this.portfolioCode = portfolioCode;
	}

	/**
	 * @return the processingSite
	 */
	public String getProcessingSite() {
		return processingSite;
	}

	/**
	 * @param processingSite
	 *            the processingSite to set
	 */
	public void setProcessingSite(String processingSite) {
		this.processingSite = processingSite;
	}

	/**
	 * @return the processType
	 */
	public String getProcessType() {
		return processType;
	}

	/**
	 * @param processType
	 *            the processType to set
	 */
	public void setProcessType(String processType) {
		this.processType = processType;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email
	 *            the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

}
